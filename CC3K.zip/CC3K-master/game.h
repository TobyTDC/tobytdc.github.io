#ifndef GAME_H
#define GAME_H
#include "cell.h"
#include <fstream>
#include <string>
#include <utility> 
#include <iostream>


class Strategy;
class PC;
class Enemy;
class Item;

class Game{
	std::ifstream *ifs;
	bool enemyMove;
	PC *pc;   
    std::vector<Enemy*> enemies;
    std::vector<Item*> items;
    int floorCount;
    std::string action; 
    bool custom;
    int pcChamber;
    bool MH;
    std::string playerRace;
    std::string fileName;
    std::vector<std::vector<Cell>> board;
    std::vector<Strategy*> strategies;
    std::vector<std::vector<std::pair<int, int>>> chamberCoord;
public:
	Game(std::ifstream *ifs, bool custom, std::string fileName);

	void restart();
	void resetBoard();
	void changeEnemyState();
	void initBoard();
	void add_observer(Cell &c);
	void spawnStair();
	void spawnItems();
	void spawnEnemies();
	void spawnPlayer();
	void spawnOther();
	int getFloor() const;
	void goUp();
	void setRace(std::string cmd);
	bool pcAlive() const;
	void movePC(int dir);
	void attack(int dir);
	void drink(int dir);
	void setHostile();
	void moveEnemies();
	
	~Game();

	friend std::ostream &operator<<(std::ostream &out, Game &g);
};

typedef void (Game::*GameMemFnPtr)(int dir);
void directionHandler(std::string cmd, Game &g, GameMemFnPtr function);
bool sortEnemy(Enemy *i, Enemy *j);
#endif
