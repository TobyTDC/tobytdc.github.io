#ifndef ITEM_H
#define ITEM_H
#include <iostream>
#include <string>
#include "character.h"
#include "pc.h"
class Cell;

class Item{

public:
    virtual std::string use(PC& player) = 0; //the player character could use the items 
                                      //this method will modify the player character
    virtual char getToken() = 0;
    virtual std::string alert(PC &pc) = 0;// return the message when PC sees the item
    virtual ~Item();
    virtual std::string getName() = 0;
    virtual Cell *getCellPtr() = 0; //return the cell pointer of the item
};

#endif

