#include <string>
#include <stdlib.h>
#include "troll.h"
#include "human.h"
#include "dwarf.h"
#include "elf.h"
#include "orc.h"
#include "halfling.h"
#include "merchant.h"
#include "dragon.h"
#include <cmath>
#include "cell.h"
using namespace std;

Troll::Troll(int x, int y, Cell *cellPtr) {
    race = "Troll";
    hp = 120;
    atk = 25;
    def = 15;
    gold = 0;

    this->x = x;
    this->y = y;
    this->cellPtr = cellPtr;
    maxHp = 120;

    adjAtk = 0;
    adjDef = 0;
    usedPotion = {{"RH", false}, {"BA", false}, {"BD", false}, {"PH", false}, {"WA",false}, {"WD", false}};

    token = '@';
}

Troll::~Troll() {}

string Troll::attack(Character &c){
  c.getCellPtr()->setAttacked();
  if(hp <= 0) return "";
  return c.defend(*this);
}

string Troll::defend(Elf &e){
   int harm = ceil((100.00/(100.00 + def)) * e.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += e.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   modHp(-harm);
   str += e.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str; 
}

string Troll::defend(Halfling &ha){
   int harm = ceil((100.00/(100.00 + def)) * ha.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += ha.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str; 
}

string Troll::defend(Dwarf &d){
   int harm = ceil((100.00/(100.00 + def)) * d.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += d.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str; 
}

string Troll::defend(Human &h){
   int harm = ceil((100.00/(100.00 + def)) * h.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += h.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str;  
}

string Troll::defend(Orc &o){
   int harm = ceil((100.00/(100.00 + def)) * o.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += o.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str; 
 }

string Troll::defend(Dragon &dr){
   int harm = ceil((100.00/(100.00 + def)) * dr.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += dr.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str; 
}

string Troll::defend(Merchant &m){
   int harm = ceil((100.00/(100.00 + def)) * m.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += m.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str; 
}

