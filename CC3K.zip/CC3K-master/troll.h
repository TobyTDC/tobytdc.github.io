# ifndef TROLL_H
# define TROLL_H

#include "halfling.h"

#include <string>
#include "pc.h"

class Troll : public PC {
public:
  Troll(int x, int y, Cell *cellPtr);
  ~Troll();
  std::string attack(Character &c) override;
  std::string defend(Elf &e) override;
  std::string defend(Halfling &ha) override;
  std::string defend(Dwarf &d) override;
  std::string defend(Human &h) override;
  std::string defend(Orc &o) override;
  std::string defend(Dragon &dr) override;
  std::string defend(Merchant &m) override;
};
  
# endif
