# ifndef VAMPIRE_H
# define VAMPIRE_H

#include <string>
#include "pc.h"

class Human;
class Dwarf;
class Elf;
class Orc;
class Halfling;
class Merchant;
class Dragon;

class Vampire : public PC {
public:
  Vampire(int x, int y, Cell *cellPtr);
  ~Vampire();
  using Character::attack;
  std::string attack(Character &c) override;
  std::string defend(Elf &e) override;
  std::string defend(Halfling &ha) override;
  std::string defend(Dwarf &d) override;
  std::string defend(Human &h) override;
  std::string defend(Orc &o) override;
  std::string defend(Dragon &dr) override;
  std::string defend(Merchant &m) override;
};
  
# endif
