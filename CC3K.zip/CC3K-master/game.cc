#include "game.h"
#include <sstream>
#include <stdlib.h>
#include <time.h>
#include "everything.h"
#include <algorithm>

using namespace std;

Game::Game(ifstream *ifs, bool custom, string fileName): ifs{ifs}, custom{custom}, fileName{fileName}, board(25), chamberCoord(5){
	floorCount = 1;
	enemyMove = true;
	MH = false; //default merchant hostility
	playerRace = "shade"; //defualt race
	//strategies
	strategies.emplace_back(new RH{});
	strategies.emplace_back(new BD{});
	strategies.emplace_back(new BA{});
	strategies.emplace_back(new PH{});
	strategies.emplace_back(new WA{});
	strategies.emplace_back(new WD{});

}




void Game::restart(){
	action = ""; // reset action message
	enemies.clear();
	items.clear();
	delete pc;
	resetBoard();
	floorCount = 1;
	ifs->close();
	ifs->open(fileName); // reset input file
	if(custom){
		spawnOther();
	}else{
		spawnPlayer();
		spawnOther();
	}
	enemyMove = true;
	MH = false;
}


void Game::resetBoard(){
	for(int i = 0; i < 25; ++i){
		for(auto it = board[i].begin(); it != board[i].end(); ++it){
			it->clearChar();
			it->clearItem();
		}
	}
}

void Game::changeEnemyState(){
	enemyMove = !enemyMove;
}

void Game::add_observer(Cell &c){
	try{  	
		c.attach(&((board.at(c.getX()-1)).at(c.getY()-1)));
	}catch(out_of_range){}
	try{
		c.attach(&((board.at(c.getX()-1)).at(c.getY())));
	}catch(out_of_range){}
	try{
		c.attach(&((board.at(c.getX()-1)).at(c.getY()+1)));
	}catch(out_of_range){}
	try{
		c.attach(&((board.at(c.getX())).at(c.getY()-1)));
	}catch(out_of_range){}
	try{  	
		c.attach(&((board.at(c.getX())).at(c.getY()+1)));
	}catch(out_of_range){}
	try{  	
		c.attach(&((board.at(c.getX()+1)).at(c.getY()-1)));
	}catch(out_of_range){}
	try{  	
		c.attach(&((board.at(c.getX()+1)).at(c.getY())));
	}catch(out_of_range){}
	try{  	
		c.attach(&((board.at(c.getX()+1)).at(c.getY()+1)));
	}catch(out_of_range){}
}


void Game::initBoard(){	
	string s;
	int rowcount = 0;
	int colcount;
	for(int i = 0; i < 25; ++i){	
		getline(*ifs, s);
		istringstream iss{s};
		char c;
		colcount = 0;
		while(iss >> noskipws >> c){
			switch(c){
				case '-': {
						  board[rowcount].emplace_back(Cell{CellType::HWall, rowcount, colcount});
						  colcount++;
						  break;
					  }
				case '|' : {
						   board[rowcount].emplace_back(Cell{CellType::VWall, rowcount, colcount});
						   colcount++;
						   break;
					   }
				case '.' : {
						   board[rowcount].emplace_back(Cell{CellType::Floor, rowcount, colcount});
						   colcount++;
						   break;
					   }
				case '+' : {
						   board[rowcount].emplace_back(Cell{CellType::Door, rowcount, colcount});
						   colcount++;
						   break;
					   }
				case ' ' : {
						   board[rowcount].emplace_back(Cell{CellType::WhiteSpace, rowcount, colcount});
						   colcount++;
						   break;
					   }
				case '#' : {
						   board[rowcount].emplace_back(Cell{CellType::Passage, rowcount, colcount});
						   colcount++;
						   break;
					   }
				default: {
						 board[rowcount].emplace_back(Cell{CellType::Floor, rowcount, colcount});
						 colcount++;
						 break;
					 }

			}
		}
		rowcount++;
	}
	if(custom) {
		ifs->close();
		ifs->open(fileName); // for customization of enemies and items
	}else{

		//chamber 0 
		for(int i = 3; i <= 6; ++i){
			for(int j = 3; j <= 28; ++j){
				chamberCoord[0].emplace_back(pair<int,int>(i,j));
			}
		}
		//chamber 1
		for(int i = 3; i <= 4; ++i){
			for(int j = 39; j <= 61; ++j){
				chamberCoord[1].emplace_back(pair<int,int>(i,j));
			}
		}
		for(int i = 39; i <= 69; ++i){
			chamberCoord[1].emplace_back(pair<int, int>(5, i));
		}
		for(int i = 39; i <= 72; ++i){
			chamberCoord[1].emplace_back(pair<int, int>(6, i));
		}
		for(int i = 7; i <= 12; ++i){
			for(int j = 61; j <= 75; ++j){
				chamberCoord[1].emplace_back(pair<int,int>(i,j));
			}
		}

		//chamber 2
		for(int i = 10; i <= 12; ++i){
			for(int j = 39; j <= 49; ++j){
				chamberCoord[2].emplace_back(pair<int,int>(i,j));
			}
		}

		//chamber 3
		for(int i = 15; i <= 21; ++i){
			for(int j = 4; j <= 24; ++j){
				chamberCoord[3].emplace_back(pair<int,int>(i,j));
			}
		}

		//chamber 4
		for(int i = 16; i <= 18; ++i){
			for(int j = 65; j <= 75; ++j){
				chamberCoord[4].emplace_back(pair<int,int>(i,j));
			}
		}

		for(int i = 19; i <= 21; ++i){
			for(int j = 37; j <= 75; ++j){
				chamberCoord[4].emplace_back(pair<int,int>(i,j));	
			}
		}
	}

	for(int i = 0; i < 25; ++i){
		for(auto it = board[i].begin(); it != board[i].end(); ++it){
			add_observer(*it);
		}
	}
}

bool sortEnemy(Enemy *i, Enemy *j){
	if(i->getX() == j->getX()) return i->getY() <= j->getY();
	return i->getX() <= j->getX();
}




void Game::spawnOther(){
	if(custom){
		string s;
		for(int j = 0; j < 25; ++j){ // j is rowcount
			getline(*ifs, s);
			istringstream iss {s};
			char c;
			int colcount = 0;
			while(iss >> noskipws >> c){
				switch(c){
					case '0' : {
							   //RH	
							   items.emplace_back(new Potion{"RH", strategies[0], &board[j][colcount]});
							   board[j][colcount].set(items.back());
							   colcount++; 
							   break;
						   }
					case '1' : {
							   //BA
							   items.emplace_back(new Potion{"BA", strategies[1], &board[j][colcount]});
							   board[j][colcount].set(items.back());
							   colcount++; 
							   break;
						   }
					case '2' : {
							   //BD
							   items.emplace_back(new Potion{"BD", strategies[2], &board[j][colcount]});
							   board[j][colcount].set(items.back());
							   colcount++; 
							   break;
						   }
					case '3' : {
							   //PH
							   items.emplace_back(new Potion{"PH", strategies[3], &board[j][colcount]});
							   board[j][colcount].set(items.back());
							   colcount++; 
							   break;
						   }
					case '4' : {
							   //WA
							   items.emplace_back(new Potion{"WA", strategies[4], &board[j][colcount]});
							   board[j][colcount].set(items.back());
							   colcount++; 
							   break;
						   }
					case '5' : {
							   //WD
							   items.emplace_back(new Potion{"WD", strategies[5], &board[j][colcount]});
							   board[j][colcount].set(items.back());
							   colcount++; 
							   break;
						   }
					case '6' : {
							   //normal gold pile
							   items.emplace_back(new Gold{2, &board[j][colcount]});
							   board[j][colcount].set(items.back());
							   colcount++; 
							   break;
						   }
					case '7' : {
							   //small hoard
							   items.emplace_back(new Gold{1, &board[j][colcount]});
							   board[j][colcount].set(items.back());
							   colcount++; 
							   break;
						   }
					case '8' : {
							   //merchant hoard
							   items.emplace_back(new Gold{4, &board[j][colcount]});
							   board[j][colcount].set(items.back());
							   colcount++; 
							   break;
						   }
					case '9' : {
							   //dragon hoard
							   items.emplace_back(new Gold{6, &board[j][colcount]});
							   board[j][colcount].set(items.back());
							   colcount++; 
							   break;
						   }
					case '@' : {
							   //pc
							   if(playerRace == "shade"){
								   pc = new Shade{j, colcount, &board[j][colcount]};
							   }else if (playerRace == "drow"){
								   pc = new Drow{j, colcount, &board[j][colcount]};
							   }else if (playerRace == "vampire"){
								   pc = new Vampire{j, colcount, &board[j][colcount]};
							   }else if (playerRace == "troll"){
								   pc = new Troll{j, colcount, &board[j][colcount]};
							   }else{
								   pc = new Goblin{j, colcount, &board[j][colcount]};
							   } 
							   board[j][colcount].set(pc);
							   colcount++; 
							   action += "Player character has spawned. "; 
							   break;
						   }
					case '\\' : {
							    //stair
							    board[j][colcount].setStair();
							    colcount++; 
							    break;
						    }

					case 'H' : {
							   //human
							   enemies.emplace_back(new Human{j, colcount, &board[j][colcount]});
							   board[j][colcount].set(enemies.back());
							   colcount++; 
							   break;
						   }
					case 'W' : {
							   //dwarf
							   enemies.emplace_back(new Dwarf{j, colcount, &board[j][colcount]});
							   board[j][colcount].set(enemies.back());
							   colcount++; 
							   break;
						   }
					case 'E' : {
							   //elf
							   enemies.emplace_back(new Elf{j, colcount, &board[j][colcount]});
							   board[j][colcount].set(enemies.back());
							   colcount++; 
							   break;
						   }
					case 'O' : {
							   //orc
							   enemies.emplace_back(new Orc{j, colcount, &board[j][colcount]});
							   board[j][colcount].set(enemies.back());
							   colcount++; 
							   break;

						   }
					case 'M' : {
							   //merchant
							   enemies.emplace_back(new Merchant{j, colcount, &board[j][colcount]});
							   board[j][colcount].set(enemies.back());
							   colcount++; 
							   break;
						   }
					case 'D' : {
							   //dragon
							   enemies.emplace_back(new Dragon{j, colcount, &board[j][colcount]});
							   board[j][colcount].set(enemies.back());
							   colcount++; 
							   break;
						   }
					case 'L' : {
							   //Halfling
							   enemies.emplace_back(new Halfling{j, colcount, &board[j][colcount]});
							   board[j][colcount].set(enemies.back());
							   colcount++; 
							   break;
						   }
					default:colcount++; 
						break;
				}
			}
		}
		//add dragon pointer and gold pointer
		for(auto it = items.begin(); it != items.end(); ++it){
			Gold *gold = dynamic_cast<Gold*>(*it);
			if(gold && gold->isHoard()){
				Cell *hcell = gold->getCellPtr();
				for(auto it2 = hcell->getObservers().begin();
						it2 != hcell->getObservers().end(); ++it2){
					Dragon *dragon = dynamic_cast<Dragon *>((*it2)->returnCharPtr());
					if(dragon){
						gold->setDragon(dragon);
						dragon->setGoldPtr(gold);
					}
				}
			}
		}

	}else{
		spawnStair();
		spawnItems();
		spawnEnemies();		
	}
	if(MH){
		setHostile();
	}
}

void Game::spawnPlayer(){
	int chamber;
	int cell;
	chamber = rand() % 5;
	pcChamber = chamber;
	int x, y;
	do{
		cell = rand() % (chamberCoord[chamber].size());	   
		x = get<0>(chamberCoord[chamber][cell]);
		y = get<1>(chamberCoord[chamber][cell]);
	}while(!(board[x][y].isOccupiable()));

	if(playerRace == "shade"){
		pc = new Shade{x, y, &board[x][y]};
	}else if (playerRace == "drow"){
		pc = new Drow{x, y, &board[x][y]};
	}else if (playerRace == "vampire"){
		pc = new Vampire{x, y, &board[x][y]};
	}else if (playerRace == "troll"){
		pc = new Troll{x, y, &board[x][y]};
	}else{
		pc = new Goblin{x, y, &board[x][y]};
	}
	board[x][y].set(pc);
	action += "Player character has spawned. "; 
}


void Game::spawnStair(){
	int chamber;
	int cell;
	int x, y;
	do{
		chamber = rand() % 5;
	}while(chamber == pcChamber);
	do{
		cell = rand() % (chamberCoord[chamber].size());
		x = get<0>(chamberCoord[chamber][cell]);
		y = get<1>(chamberCoord[chamber][cell]);
	}while(!(board[x][y].isOccupiable()));	
	board[x][y].setStair();	
}

int Game::getFloor() const{return floorCount;}
void Game::spawnItems(){
	int chamber;
	int cell;
	int type;
	int x, y;
	for(int i = 0; i < 10; ++i){
		chamber = rand() % 5;
		do{
			cell = rand() % (chamberCoord[chamber].size());

			x = get<0>(chamberCoord[chamber][cell]);
			y = get<1>(chamberCoord[chamber][cell]);
		}while(!(board[x][y].isOccupiable()));
		type = rand() % 6;

		switch(type){
			case 0: {//RH
					items.emplace_back(new Potion{"RH", strategies[0], &board[x][y]});
					break;
				} 
			case 1: {//BA
					items.emplace_back(new Potion{"BA", strategies[1], &board[x][y]});
					break;
				}
			case 2: {//BD
					items.emplace_back(new Potion{"BD", strategies[2], &board[x][y]});
					break;
				}
			case 3: {//PH
					items.emplace_back(new Potion{"PH", strategies[3], &board[x][y]});
					break;
				}
			case 4: {//WA
					items.emplace_back(new Potion{"WA", strategies[4], &board[x][y]});
					break;
				}
			case 5: {//WD
					items.emplace_back(new Potion{"WD", strategies[5], &board[x][y]});
					break;
				}
		}
		board[x][y].set(items.back());	    	
	}
	for(int i = 0; i < 10; ++i){
		chamber = rand() % 5;
		int x, y;
		do{
			cell = rand() % (chamberCoord[chamber].size());
			x = get<0>(chamberCoord[chamber][cell]);
			y = get<1>(chamberCoord[chamber][cell]);
		}while(!(board[x][y].isOccupiable()));

		type = rand() % 8;
		if(type == 0){
			//dragon hoard
			Gold *gold = new Gold{6, &board[x][y]};
			items.emplace_back(gold);
			//spawn dragon 
			int dcell;
			int dx, dy;
			do{
				dcell = rand() % ((board[x][y].getObservers().size()));
				dx = (board[x][y].getObservers()[dcell])->getX();
				dy = (board[x][y].getObservers()[dcell])->getY();
			}while(!(board[dx][dy].isOccupiable()));
			Dragon *dragon = new Dragon{x, y, &board[x][y]};
			enemies.emplace_back(dragon);
			dragon->setGoldPtr(gold);
			board[dx][dy].set(enemies.back());
			gold->setDragon(enemies.back());
		}else if (0 < type && type <= 2){
			items.emplace_back(new Gold{1, &board[x][y]});
		}else{
			items.emplace_back(new Gold{2, &board[x][y]});
		}
		board[x][y].set(items.back());
	}
}


void Game::spawnEnemies(){
	//20 enemies including dragon
	int dragon_count = enemies.size();
	int chamber;
	int cell;
	int type;
	int x, y;
	for(int i = 0; i < 20 - dragon_count; ++i){
		chamber = rand() % 5;
		do{
			cell = rand() % (chamberCoord[chamber].size());

			x = get<0>(chamberCoord[chamber][cell]);
			y = get<1>(chamberCoord[chamber][cell]);
		}while(!(board[x][y].isOccupiable()));
		type = rand() % 18;
		if(0 <= type && type < 4){	
			//human
			enemies.emplace_back(new Human{x, y, &board[x][y]});
		}else if(4 <= type && type < 7){
			//dwarf

			enemies.emplace_back(new Dwarf{x, y, &board[x][y]});
		}else if(7 <= type && type < 12){
			//halfling

			enemies.emplace_back(new Halfling{x, y, &board[x][y]});
		}else if(12 <= type && type < 14){
			//elf

			enemies.emplace_back(new Elf{x, y, &board[x][y]});
		}else if(14 <= type && type < 16){
			//orc
			enemies.emplace_back(new Orc{x, y, &board[x][y]});
		}else{
			//merchant 
			enemies.emplace_back(new Merchant{x, y, &board[x][y]});
		}
		board[x][y].set(enemies.back());
	}

	//sort enemies according to their coordinates here
	sort(enemies.begin(), enemies.end(), sortEnemy);
}

void Game::setRace(string cmd){
	if (cmd == "s") {
		playerRace = "shade"; // player is of race Shade
		cout << "Shade" << endl;
	} else if (cmd == "d") {
		playerRace = "drow"; // player is of race Drow
		cout << "Drow" << endl;
	} else if (cmd == "v") {
		playerRace ="vampire"; // player is of race Vampire
		cout << "Vampire" << endl;
	} else if (cmd == "g") {
		playerRace = "goblin"; // player is of race Goblin
		cout << "Goblin" << endl;
	} else if (cmd == "t"){ 
		playerRace ="troll"; // player is of race Troll
		cout << "Troll" << endl;
	} 
}

void Game::goUp(){
	if(pc->getCellPtr()->isStair()){
		pc->getCellPtr()->unsetStair();
		enemies.clear();
		items.clear();
		floorCount++;
		resetBoard();
		pc->getCellPtr()->set(pc);
		spawnOther();
		pc->modAdjAtk(-(pc->getAdjAtk()));
		pc->modAdjDef(-(pc->getAdjDef()));
		action += "PC moves up one floor. ";
		pc->getCellPtr()->notifyObservers(action, pc);
	}
}


void Game::setHostile(){
	for(auto it = enemies.begin(); it != enemies.end(); ++it){
		if((*it)->getToken() == 'M') (*it)->nowHostile();
	}
}


void directionHandler(string cmd, Game &g, GameMemFnPtr function){
	if (cmd == "no") { (g.*function)(1); } // ↑
	else if (cmd == "ne") { (g.*function)(2); } // ↗
	else if (cmd == "ea") { (g.*function)(3); } // →
	else if (cmd == "se") { (g.*function)(4); } // ↘
	else if (cmd == "so") { (g.*function)(5); } // ↓
	else if (cmd == "sw") { (g.*function)(6); } // ↙
	else if (cmd == "we") { (g.*function)(7); } // ←
	else if (cmd == "nw") { (g.*function)(8); } // ↖
	else {throw "Invalid direction."; }
}

void Game::drink(int dir){
	action += pc->drinkDir(dir);
	pc->getCellPtr()->notifyObservers(action, pc);
}

void Game::attack(int dir){
	int x, y;
	bool merchant;
	try{
		switch(dir){
			case 1: {
					x = pc->getX() - 1;
					y = pc->getY();
					break;
				}
			case 2: {
					x = pc->getX() - 1;
					y = pc->getY() + 1;
					break;
				}
			case 3: {
					x = pc->getX();
					y = pc->getY() + 1;
					break;
				}
			case 4: {
					x = pc->getX() + 1;
					y = pc->getY() + 1;
					break;
				}
			case 5: {
					x = pc->getX() + 1;
					y = pc->getY();
					break;
				}
			case 6: {
					x = pc->getX() + 1;
					y = pc->getY() - 1;
					break;
				}
			case 7: {
					x = pc->getX();
					y = pc->getY() - 1;
					break;
				}
			case 8: {
					x = pc->getX() - 1;
					y = pc->getY() - 1;
					break;
				}
		}
		if(dynamic_cast<Merchant *>(pc->getCellPtr()->getNeighbour(x, y)->returnCharPtr())) {
			cout << "is merchant  " << endl;
			merchant = true;
			MH = true;	
		}
		action += pc->attackDir(dir);
	}catch(string s){		
		Cell *goldCell = pc->getCellPtr()->getNeighbour(x, y);
		if(merchant){
			items.emplace_back(new Gold{4, goldCell});
			goldCell->set(items.back());
		}else{
			items.emplace_back(new Gold{2, goldCell});
			goldCell->set(items.back());
			int gx, gy;
			int cell;
			do{
				cell = rand() % (goldCell->getObservers().size());			
				gx = (goldCell->getObservers()[cell])->getX();
				gy = (goldCell->getObservers()[cell])->getY();
			}while(!(board[gx][gy].isOccupiable()));
			items.emplace_back(new Gold{2, &board[gx][gy]});
			board[gx][gy].set(items.back());
		}
		action += s;
	}
	if(MH) setHostile();
	pc->getCellPtr()->notifyObservers(action, pc);

}

void Game::movePC(int dir){
	action += pc->move(dir);
	goUp();
	pc->getCellPtr()->notifyObservers(action, pc);
}

bool Game::pcAlive() const{
	return pc->getHp() > 0;
}

void Game::moveEnemies(){
	if(dynamic_cast<Troll *>(pc)) pc->modHp(5);
	if(enemyMove){
		for(auto it = enemies.begin(); it != enemies.end(); ++it){
			if((*it)->isGoodBoy() && ((*it)->getHp() > 0)){
				(*it)->move(1);
			}else{
				(*it)->setBoy(1); // good boy
			}
		}
	}
}


//destructor
Game::~Game(){
	strategies.clear();
	enemies.clear();
	items.clear();
	delete pc;
	for(int i = 0; i < 25; ++i){
		board[i].clear();
	}
	board.clear();
	for(int i = 0; i < 5; ++i){
		chamberCoord[i].clear();
	}
	chamberCoord.clear();
}


ostream &operator<<(ostream &out, Game &g){
	for(int i = 0; i < 25; ++i){
		for(auto c : g.board[i]){
			out << c;
		}
		out << endl;
	}
	out << "Race: " << g.pc->getRace() << " Gold: " << g.pc->getGold();
	out << "                                             Floor " << g.getFloor() << endl;
	out << "HP: " << g.pc->getHp() << endl;
	out << "Atk: " << g.pc->getAtk() << endl;
	out << "Def: " << g.pc->getDef() << endl;
	out << "Action: " << g.action << endl;
	g.action = "";
	return out;
}
