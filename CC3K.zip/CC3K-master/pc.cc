#include <string>
#include "cell.h"
#include "pc.h"
using namespace std;

void PC::modAdjAtk(int adj) { adjAtk += adj; }
void PC::modAdjDef(int adj) { adjDef += adj; }
int PC::getAtk() const { return adjAtk + atk; }
int PC::getDef() const { return adjDef + def; }
int PC::getAdjAtk() const { return adjAtk; }
int PC::getAdjDef() const { return adjDef; }
//int PC::getMaxHp() const { return maxHp; }
void PC::setUsedPotion(string potion) { usedPotion[potion] = true; }
bool PC::isPotionUsed(string potion) {
  if (potion == "G") return false;
  return usedPotion[potion];
}

string PC::drinkDir(int d) {
  if (d == 1) {
    Cell *itemCell = cellPtr->getNeighbour(x - 1, y); // get the north Cell ptr or nullptr
    if (itemCell) { // there is a empty cell (not nullptr)
      Item* item = itemCell->returnItemPtr(); // return the pointer of item on that cell
      if (item && item->getToken() == 'P') { // check it is potion
        return item->use(*this);
      } else { // that's a gold, not potion
        throw "North: no target. ";
      }
    } else { // no Potion on the north
      throw "North: no target. ";
    }
  } else if (d == 2) {
    Cell *itemCell = cellPtr->getNeighbour(x - 1, y + 1); // get the no-ea Cell ptr or nullptr
    if (itemCell) { // there is a empty cell (not nullptr)
      Item* item = itemCell->returnItemPtr(); // return the pointer of item on that cell
      if (item && item->getToken() == 'P') { // check it is potion
        return item->use(*this);
      } else { // that's a gold, not potion
        throw "North-East: no target. ";
      }
    } else { // no Potion on the no-ea
      throw "North-East: no target. ";
    }
  } else if (d == 3) {
    Cell *itemCell = cellPtr->getNeighbour(x, y + 1); // get the east Cell ptr or nullptr
    if (itemCell) { // there is a empty cell (not nullptr)
      Item* item = itemCell->returnItemPtr(); // return the pointer of item on that cell
      if (item && item->getToken() == 'P') { // check it is potion
        return item->use(*this);
      } else { // that's a gold, not potion
        throw "East: no target. ";
      }
    } else { // no Potion on the east
      throw "East: no target. ";
    }
  } else if (d == 4) {
    Cell *itemCell = cellPtr->getNeighbour(x + 1, y + 1); // get the so-ea Cell ptr or nullptr
    if (itemCell) { // there is a empty cell (not nullptr)
      Item* item = itemCell->returnItemPtr(); // return the pointer of item on that cell
      if (item && item->getToken() == 'P') { // check it is potion
        return item->use(*this);
      } else { // that's a gold, not potion
        throw "South-East: no target. ";
      }
    } else { // no Potion on the so-ea
      throw "South-East: no target. ";
    }
  } else if (d == 5) {
    Cell *itemCell = cellPtr->getNeighbour(x + 1, y); // get the south Cell ptr or nullptr
    if (itemCell) { // there is a empty cell (not nullptr)
      Item* item = itemCell->returnItemPtr(); // return the pointer of item on that cell
      if (item && item->getToken() == 'P') { // check it is potion
        return item->use(*this);
      } else { // that's a gold, not potion
        throw "South: no target. ";
      }
    } else { // no Potion on the south
      cout << "use south false" << endl;
      throw "South: no target. ";
    }
  } else if (d == 6) {
    Cell *itemCell = cellPtr->getNeighbour(x + 1, y - 1); // get the so-we Cell ptr or nullptr
    if (itemCell) { // there is a empty cell (not nullptr)
      Item* item = itemCell->returnItemPtr(); // return the pointer of item on that cell
      if (item && item->getToken() == 'P') { // check it is potion
        return item->use(*this);
      } else { // that's a gold, not potion
        throw "South-West: no target. ";
      }
    } else { // no Potion on the so-we
      throw "South-West: no target. ";
    }
  } else if (d == 7) {
    Cell *itemCell = cellPtr->getNeighbour(x, y - 1); // get the west Cell ptr or nullptr
    if (itemCell) { // there is a empty cell (not nullptr)
      Item* item = itemCell->returnItemPtr(); // return the pointer of item on that cell
      if (item && item->getToken() == 'P') { // check it is potion
        return item->use(*this);
      } else { // that's a gold, not potion
        throw "West: no target. ";
      }
    } else { // no Potion on the west
      throw "West: no target. ";
    }
  } else { // d == 8 
    Cell *itemCell = cellPtr->getNeighbour(x - 1, y - 1); // get the no-we Cell ptr or nullptr
    if (itemCell) { // there is a empty cell (not nullptr)
      Item* item = itemCell->returnItemPtr(); // return the pointer of item on that cell
      if (item && item->getToken() == 'P') { // check it is potion
        return item->use(*this);
      } else { // that's a gold, not potion
        throw "North-West: no target. ";
      }
    } else { // no Potion on the no-we
      throw "North-West: no target. ";
    }
  }
}