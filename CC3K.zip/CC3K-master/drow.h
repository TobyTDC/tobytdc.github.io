# ifndef DROW_H
# define DROW_H

#include <string>
#include "pc.h"

class Halfling;

class Drow : public PC {
public:
  Drow(int x, int y, Cell *cellPtr);
  ~Drow();
  using Character::attack;
  std::string attack(Character &c) override;
  std::string defend(Elf &e) override;
  std::string defend(Halfling &ha) override;
  std::string defend(Dwarf &d) override;
  std::string defend(Human &h) override;
  std::string defend(Orc &o) override;
  std::string defend(Dragon &dr) override;
  std::string defend(Merchant &m) override;
};
  
# endif
