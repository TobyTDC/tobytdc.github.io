#include <iostream>
#include <string>
#include <stdlib.h>
#include <time.h>
#include "enemy.h"

using namespace std;

int Enemy::getAtk() const { return atk; }
int Enemy::getDef() const { return def; }

bool Enemy::isGoodBoy() const { return goodBoy; }

void Enemy::setBoy(int i) {
  if (i == 1) goodBoy = true;
  else goodBoy = false;
}
void Enemy::nowHostile() {};
bool Enemy::isHostile() { return true; }
string Enemy::move(int d) {
	//cout << "enemy " << token << " now at " << x << " " << y << endl;
  while(1) {
	try {
	  //srand(time(NULL));
	  int r = rand() % 8 + 1; // rand from 1 to 8
	  Character::move(r);
	} catch(...) { // invalid move
	  continue; // choose another rand
	}
	//cout << "enemy move succeed" << endl;
	//cout << "enemy " << token << " now at " << x << " " << y << endl;
	break; //if succeed, break
  }
  return "";
}
