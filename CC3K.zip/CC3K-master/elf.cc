#include <iostream>
#include <string>
#include <stdlib.h>
#include <time.h>
#include "elf.h"
#include "shade.h"
#include "drow.h"
#include "vampire.h"
#include "troll.h"
#include "goblin.h"
#include <cmath>
using namespace std;

Elf::Elf(int x, int y, Cell *cellPtr) {
  	race = "Elf";
  	hp = 140;
  	atk = 30;
  	def = 10;
    this->x = x;
    this->y = y;
    this->cellPtr = cellPtr;

    int r = rand() % 2;
    if (r) {
      gold = 2;
    } else {
      gold = 1;
    }
    maxHp = 140;
    goodBoy = true;
    token = 'E';
}

Elf::~Elf() {}

string Elf::attack(Character &c) {
  if (c.getHp() <= 0) return "";
  if (hp <= 0) return "";
  return c.defend(*this);
}

string Elf::defend(Shade &s) {
  int harm = ceil((100.00/(100.00 + def)) * s.getAtk());
  modHp(-harm);
  string str = "";
  str += "PC deals ";
  str += to_string(harm);
  str += " damage to E (";
  str += to_string(getHp());
  str += " HP). ";
  if (hp <= 0) {
    s.modGold(gold);
    cellPtr->clearChar();
    str += "E is killed. PC gets ";
    str += to_string(gold);
    str += " gold. ";
  }
  return str;
}

string Elf::defend(Drow &d) {
  int harm = ceil((100.00/(100.00 + def)) * d.getAtk());
  modHp(-harm);
  string str = "";
  str += "PC deals ";
  str += to_string(harm);
  str += " damage to E (";
  str += to_string(getHp());
  str += " HP). ";
  if (hp <= 0) {
    d.modGold(gold);
    cellPtr->clearChar();
    str += "E is killed. PC gets ";
    str += to_string(gold);
    str += " gold. ";
  }
  return str;
}

string Elf::defend(Vampire &v) {
  int harm = ceil((100.00/(100.00 + def)) * v.getAtk());
  modHp(-harm);
  string str = "";
  v.modHp(5);
  str += "PC deals ";
  str += to_string(harm);
  str += " damage to E (";
  str += to_string(getHp());
  str += " HP). ";
  if (hp <= 0) {
    v.modGold(gold);
    cellPtr->clearChar();
    str += "E is killed. PC gets ";
    str += to_string(gold);
    str += " gold. ";
  }
  return str;
}

string Elf::defend(Troll &t) {
  int harm = ceil((100.00/(100.00 + def)) * t.getAtk());
  modHp(-harm);
  string str = "";
  str += "PC deals ";
  str += to_string(harm);
  str += " damage to E (";
  str += to_string(getHp());
  str += " HP). ";
  if (hp <= 0) {
    t.modGold(gold);
    cellPtr->clearChar();
    str += "E is killed. PC gets ";
    str += to_string(gold);
    str += " gold. ";
  }
  return str;
}

string Elf::defend(Goblin &g) {
  int harm = ceil((100.00/(100.00 + def)) * g.getAtk());
  modHp(-harm);
  string str = "";
  str += "PC deals ";
  str += to_string(harm);
  str += " damage to E (";
  str += to_string(getHp());
  str += " HP). ";
  if (hp <= 0) {
    g.modGold(gold+5);
    cellPtr->clearChar();
    str += "E is killed. PC gets ";
    str += to_string(gold+5);
    str += " gold. ";
  }
  return str;
}
