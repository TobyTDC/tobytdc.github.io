# ifndef HUMAN_H
# define HUMAN_H

#include <string>
#include "enemy.h"

class Character;
class Shade;
class Drow;
class Vampire;
class Troll;
class Goblin;

class Human : public Enemy {
public:
  Human(int x, int y, Cell *cellPtr);
  ~Human();
  std::string attack(Character &c) override;
  std::string defend(Shade &s) override;
  std::string defend(Drow &d) override;
  std::string defend(Vampire &v) override;
  std::string defend(Troll &t) override;
  std::string defend(Goblin &g) override;

};
  
# endif
