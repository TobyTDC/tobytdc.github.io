#include "potion.h"

Potion::Potion(string name, Strategy *straPtr, Cell *cellPtr): name{name}, straPtr{straPtr}, cellPtr{cellPtr}{}

string Potion::getName(){
	return name;
}

string Potion::alert(PC &pc){
	if(!pc.isPotionUsed(getName())){
		return "PC sees an unknown potion. ";
	}
	return "PC sees a " + getName() + " potion. ";
}

string Potion::use(PC &pc){
	straPtr->use(pc);
	cellPtr->clearItem();
	pc.setUsedPotion(getName());
	return "PC uses " + getName() + ". ";
}

char Potion::getToken(){
	return 'P';
}


Cell *Potion::getCellPtr(){
    return cellPtr;
}

Potion:: ~Potion(){
}

