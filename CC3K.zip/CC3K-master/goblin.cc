#include <string>
#include <stdlib.h>
#include "goblin.h"
#include "human.h"
#include "dwarf.h"
#include "elf.h"
#include "orc.h"
#include "halfling.h"
#include "merchant.h"
#include "dragon.h"
#include <cmath>
#include "cell.h"
using namespace std;

Goblin::Goblin(int x, int y, Cell *cellPtr) {
    race = "Goblin";
    hp = 110;
    atk = 15;
    def = 20;
    gold = 0;

    this->x = x;
    this->y = y;
    this->cellPtr = cellPtr;
    maxHp = 110;

    adjAtk = 0;
    adjDef = 0;
    usedPotion = {{"RH", false}, {"BA", false}, {"BD", false}, {"PH", false}, {"WA",false}, {"WD", false}};
    cout << "max hp is " << maxHp << endl;

    token = '@';
}

Goblin::~Goblin() {}

string Goblin::attack(Character &c){
  c.getCellPtr()->setAttacked();
  if(hp <= 0) return "";
  return c.defend(*this);
}

string Goblin::defend(Elf &e){

   int harm = ceil((100.00/(100.00 + def)) * e.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += e.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   modHp(-harm);
   str += e.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str; 
}

string Goblin::defend(Halfling &ha){
   int harm = ceil((100.00/(100.00 + def)) * ha.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += ha.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str; 
}

string Goblin::defend(Dwarf &d){
   int harm = ceil((100.00/(100.00 + def)) * d.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += d.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str; 
}

string Goblin::defend(Human &h){
   int harm = ceil((100.00/(100.00 + def)) * h.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += h.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str; 
}

string Goblin::defend(Orc &o){
   int harm = ceil((150.00/(100.00 + def)) * o.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += o.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str; 
}

string Goblin::defend(Dragon &dr){
   int harm = ceil((100.00/(100.00 + def)) * dr.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += dr.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    dr.getGoldPtr()->setDragonDead();
    str += "PC is killed. ";
    return str;
   }
   return str; 
}

string Goblin::defend(Merchant &m){
   int harm = ceil((100.00/(100.00 + def)) * m.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += m.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str; 
}