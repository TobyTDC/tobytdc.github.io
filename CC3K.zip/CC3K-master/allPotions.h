#ifndef ALL_POTIONS_H
#define ALL_POTIONS_H
#include <iostream>
#include "pc.h"
#include "strategy.h"
#include "drow.h"


class RH: public Strategy {
public:
	//void use(Drow &drow);// special method for drow
	void use(PC &pc) override;// restore up to 10 HP (cannot exceed maximum prescribed by race)
	RH();
	~RH();
};

class BA: public Strategy {
public:
	//void use(Drow &drow);
	void use(PC &pc) override;// increase Atk by 5
	BA();
	~BA();
};

class BD: public Strategy {
public:
	//void use(Drow &drow);
	void use(PC &pc) override;// increase Def by 5
	BD();
	~BD();
};

class PH: public Strategy {
public:
	//void use(Drow &drow);
	void use(PC &pc) override;// lose up to 10 HP (cannot fall below 0 HP)
	PH();
	~PH();
};

class WA: public Strategy {
public:
	//void use(Drow &drow);
	void use(PC &pc) override;// decrease Atk by 5
	WA();
	~WA();
};

class WD: public Strategy {
public:
	//void use(Drow &drow);
	void use(PC &pc) override;// decrease Def by 5
	WD();
	~WD();
};

#endif 


