#include "strategy.h"

Strategy::~Strategy(){}

//Strategy::Strategy(){}

