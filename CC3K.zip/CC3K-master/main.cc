
#include "game.h"
using namespace std;

int main(int argc, char *argv[]) {
  srand(time(NULL));
 cin.exceptions(ios::eofbit|ios::failbit|ios::badbit);
 string s = (argc == 1) ? "default.txt" : argv[1];
   //set input file name
 ifstream ifs{s};
 bool exception = false;
 bool custom = (argc == 1) ? false : true;
 
   Game g{&ifs, custom, s}; //create game
   g.initBoard(); //initiate board
   string cmd; 
   cout << "Please choose a race: s(Shade), t(Troll), v(Vampire), g(Goblin), d(Drow)" << endl;
   cin >> cmd;
   g.setRace(cmd);


   //end of race choosing
  GameMemFnPtr drink = &Game::drink;
  GameMemFnPtr attack = &Game::attack;
  GameMemFnPtr movePC = &Game::movePC;

  if(!custom){
   g.spawnPlayer();
   g.spawnOther();
 }else{
   g.spawnOther();
 }
 cout << g; 

 try {
   while (g.pcAlive()){
    exception = false;
    cout << "Please enter a command: " << endl;
    cin >> cmd;
    if(cmd == "u"){
     while(true){
      try{
        cout << "Please enter a direction: " << endl;
       cin >> cmd;
       directionHandler(cmd, g, drink);
       break;
      }catch(const char* s){
       cout << s << endl;
       exception = true;
       break;
      }
     }
    }else if(cmd == "a"){
     while(true){
      try{
         cout << "Please enter a direction: " << endl;
       cin >> cmd;
       directionHandler(cmd, g, attack);
       break;
      }catch(const char* s){
       cout << s << endl;
       exception = true;
       break;
      }
     }
   }else if(cmd == "f"){
     g.changeEnemyState();
     exception = true;
   }else if(cmd == "r"){
     cout << "Please choose a race: s(Shade), t(Troll), v(Vampire), g(Goblin), d(Drow)" << endl;
     cin >> cmd;
     g.setRace(cmd);
     g.restart();
     cout << g;
   }else if(cmd == "q"){
     cout << "I quit" << endl;
     break; 
   }else{
     
     while(true){
      try{
        directionHandler(cmd, g, movePC);
        break;
      }catch(const char* s){
        cout << s << endl;
        exception = true;
        break;
      }
      
    }
  }

   if(!exception){
     g.moveEnemies();
     cout << g;
   }

  }
}

  
  
  

  catch (ios::failure &) {
  }

  }