#include <iostream>
#include <string>
#include <cmath>
#include "dragon.h"
#include "shade.h"
#include "drow.h"
#include "vampire.h"
#include "troll.h"
#include "goblin.h"

using namespace std;

Dragon::Dragon(int x, int y, Cell *cellPtr) {
  	race = "Dragon";
  	hp = 150;
  	atk = 20;
  	def = 20;
  	gold = 0;
    this->x = x;
    this->y = y;
    this->cellPtr = cellPtr;
  	maxHp = 150;
    goodBoy = true;
    token = 'D';
}

Gold *Dragon::getGoldPtr(){ return goldPtr; }
void Dragon::setGoldPtr(Gold *gold){ this->goldPtr = gold; }
Dragon::~Dragon(){}

string Dragon::move(int d) {
  return "";
}

string Dragon::attack(Character &c) {
  if (c.getHp() <= 0) return "";
  if(hp <= 0) return "";
  return c.defend(*this);
}
string Dragon::defend(Shade &s){
    int harm = ceil((100.00/(100.00 + def)) * s.getAtk());
    modHp(-harm);
    string str = "";
    str += "PC deals" ;
    str += to_string(harm);
    str += " damage to D (";
    str += to_string(getHp());
    str += " HP). ";
    if(hp <= 0){
      cellPtr->clearChar();
      str += "D is killed. ";
    }
    return str;
}

string Dragon::defend(Drow &d){
    int harm = ceil((100.00/(100.00 + def)) * d.getAtk());
    modHp(-harm);
    string str = "";
    str += "PC deals" ;
    str += to_string(harm);
    str += " damage to D (";
    str += to_string(getHp());
    str += " HP). ";
    if(hp <= 0){
      cellPtr->clearChar();
      str += "D is killed. ";
    }
    return str;
}

string Dragon::defend(Vampire &v){
    int harm = ceil((100.00/(100.00 + def)) * v.getAtk());
    modHp(-harm);
    v.modHp(5);
    string str = "";
    str += "PC deals" ;
    str += to_string(harm);
    str += " damage to D (";
    str += to_string(getHp());
    str += " HP). ";
    if(hp <= 0){
      cellPtr->clearChar();
      str += "D is killed. ";
    }
    return str;
}
string Dragon::defend(Troll &t){
    int harm = ceil((100.00/(100.00 + def)) * t.getAtk());
    modHp(-harm);
    string str = "";
    str += "PC deals" ;
    str += to_string(harm);
    str += " damage to D (";
    str += to_string(getHp());
    str += " HP). ";
    if(hp <= 0){
      cellPtr->clearChar();
      str += "D is killed. ";
    }
    return str;
}

string Dragon::defend(Goblin &g){
    int harm = ceil((100.00/(100.00 + def)) * g.getAtk());
    modHp(-harm);
    string str = "";
    str += "PC deals" ;
    str += to_string(harm);
    str += " damage to D (";
    str += to_string(getHp());
    str += " HP). ";
    if(hp <= 0){
      g.modHp(5); 
      cellPtr->clearChar();
      str += "D is killed. PC gets 5 gold. ";
    }
    return str;
}
