#include <iostream>
#include <string>
#include "merchant.h"
#include "shade.h"
#include "drow.h"
#include "vampire.h"
#include "troll.h"
#include "goblin.h"
#include <cmath>
#include "cell.h"
using namespace std;

Merchant::Merchant(int x, int y, Cell *cellPtr) {
  	race = "Merchant";
  	hostile = false;
  	hp = 30;
  	atk = 70;
  	def = 5;
  	gold = 4;
    this->x = x;
    this->y = y;
    this->cellPtr = cellPtr;

    goodBoy = true;

    maxHp = 30;
    token = 'M';
}

Merchant::~Merchant() {}

void Merchant::nowHostile() {
  hostile = true;
}

bool Merchant::isHostile() { return hostile; }

string Merchant::attack(Character &c){
  if (c.getHp() <= 0) return "";
  if(hp <= 0) return "";
  return c.defend(*this);
}
string Merchant::defend(Shade &s){
  hostile = true;
  int harm = ceil((100.00/(100.00 + def)) * s.getAtk());
  modHp(-harm);
  string str = "";
  str += "PC deals " ;
  str += to_string(harm);
  str += " damage to M (";
  str += to_string(getHp());
  str += " HP). ";
  if(hp <= 0){
    cellPtr->clearChar();
    str += "content is " ;
    str+=cellPtr->getContent();
    str += "M is killed. ";
    throw str;
  }
  return str;
}
string Merchant::defend(Drow &d){
  hostile = true;
  int harm = ceil((100.00/(100.00 + def)) * d.getAtk());
  modHp(-harm);
  string str = "";
  str += "PC deals " ;
  str += to_string(harm);
  str += " damage to M (";
  str += to_string(getHp());
  str += " HP). ";
  if(hp <= 0){
    cellPtr->clearChar();
    str += "M is killed. ";
    throw str;
  }
  return str;
}
string Merchant::defend(Vampire &v){
  hostile = true;
  int harm = ceil((100.00/(100.00 + def)) * v.getAtk());
  modHp(-harm);
  v.modHp(5);
  string str = "";
  str += "PC deals " ;
  str += to_string(harm);
  str += " damage to M (";
  str += to_string(getHp());
  str += " HP). ";
  if(hp <= 0){
    cellPtr->clearChar();
    str += "M is killed. ";
    throw str;
  }
  return str;
}

string Merchant::defend(Troll &t){
  hostile = true;
  int harm = ceil((100.00/(100.00 + def)) * t.getAtk());
  modHp(-harm);
  string str = "";
  str += "PC deals " ;
  str += to_string(harm);
  str += " damage to M (";
  str += to_string(getHp());
  str += " HP). ";
  if(hp <= 0){
    cellPtr->clearChar();
    str += "M is killed. ";
    throw str;
  }
  return str;
}
string Merchant::defend(Goblin &g){
  hostile = true;
  int harm = ceil((100.00/(100.00 + def)) * g.getAtk());
  modHp(-harm);
  string str = "";
  str += "PC deals " ;
  str += to_string(harm);
  str += " damage to M (";
  str += to_string(getHp());
  str += " HP). ";
  if(hp <= 0){
    cellPtr->clearChar();
    g.modGold(5);
    str += "M is killed. PC gets 5 gold. ";
    throw str;
  }
  return str;
}
