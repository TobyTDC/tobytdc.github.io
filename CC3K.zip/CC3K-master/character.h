#ifndef CHARACTER_H
#define CHARACTER_H

#include <string>

class Cell;

class Shade;
class Drow;
class Vampire;
class Troll;
class Goblin;
class Human;
class Dwarf;
class Elf;
class Orc;
class Halfling;
class Merchant;
class Dragon;

class Character {
protected:
  std::string race;
  int hp;
  int atk;
  int def;
  int gold;
  int maxHp;

  int x;
  int y;
  char token;
  Cell *cellPtr;

public:

  virtual ~Character() = 0;
  virtual void setBoy(int i);
  int getHp() const;
  virtual int getAtk() const = 0;
  virtual int getDef() const = 0;
  int getGold() const;
  char getToken() const;
  std::string getRace() const;
  Cell *getCellPtr() const;
  int getMaxHp() const;
  void modHp(int h); // modHp(5) means +5 HP
  void modGold(int g); // modGold(5) means +5 Gold
  virtual bool isHostile();
  int getX() const;
  int getY() const;
  void setX(int nx);
  void setY(int ny);
  std::string attackDir(int d);
  virtual std::string attack(Character &c) = 0;
  virtual std::string defend(Shade &s);
  virtual std::string defend(Drow &d);
  virtual std::string defend(Vampire &v);
  virtual std::string defend(Troll &t);
  virtual std::string defend(Goblin &g);
  virtual std::string defend(Elf &e);
  virtual std::string defend(Halfling &ha);
  virtual std::string defend(Dwarf &w);
  virtual std::string defend(Human &h);
  virtual std::string defend(Orc &o);
  virtual std::string defend(Dragon &d);
  virtual std::string defend(Merchant &m);
  virtual std::string move(int d);
};

#endif
