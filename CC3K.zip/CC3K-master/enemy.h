# ifndef ENEMY_H
# define ENEMY_H

#include <string>
#include <map>

#include "character.h"


class Enemy : public Character {
protected:
  bool goodBoy;
public:
  int getAtk() const override;
  int getDef() const override;
  std::string move(int d) override;
  virtual bool isHostile() override;
  virtual void nowHostile();
  bool isGoodBoy() const;
  void setBoy(int i) override; // 1 is good boy, 0 is bad boy
};
  
# endif

