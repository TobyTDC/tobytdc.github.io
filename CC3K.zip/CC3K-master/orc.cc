#include <iostream>
#include <string>
#include <stdlib.h>
#include <time.h>
#include "orc.h"
#include <cmath>
#include "shade.h"
#include "drow.h"
#include "vampire.h"
#include "troll.h"
#include "goblin.h"
#include "cell.h"
using namespace std;

Orc::Orc(int x, int y, Cell *cellPtr) {
  	race = "Orc";
  	hp = 180;
  	atk = 30;
  	def = 25;

    this->x = x;
    this->y = y;
    this->cellPtr = cellPtr;
    int r = rand() % 2;
    if (r) {
      gold = 2;
    } else {
      gold = 1;
    }

    maxHp = 180;
    goodBoy = true;
    token = 'O';
}

Orc::~Orc() {}

string Orc::attack(Character &c) {
  if (c.getHp() <= 0) return "";
  if (hp <= 0) return "";
  return c.defend(*this);
}

string Orc::defend(Shade &s) {
  int harm = ceil((100.00/(100.00 + def)) * s.getAtk());
  modHp(-harm);
  string str = "";
  str += "PC deals ";
  str += to_string(harm);
  str += " damage to O (";
  str += to_string(getHp());
  str += " HP). ";
  if (hp <= 0) {
    s.modGold(gold);
    cellPtr->clearChar();
    str += "O is killed. PC gets ";
    str += to_string(gold);
    str += " gold. ";
  }
  return str;
}

string Orc::defend(Drow &d) {
  int harm = ceil((100.00/(100.00 + def)) * d.getAtk());
  modHp(-harm);
  string str = "";
  str += "PC deals ";
  str += to_string(harm);
  str += " damage to O (";
  str += to_string(getHp());
  str += " HP). ";
  if (hp <= 0) {
    d.modGold(gold);
    cellPtr->clearChar();
    str += "O is killed. PC gets ";
    str += to_string(gold);
    str += " gold. ";
  }
  return str;
}

string Orc::defend(Vampire &v) {
  int harm = ceil((100.00/(100.00 + def)) * v.getAtk());
  modHp(-harm);
  string str = "";
  v.modHp(5);
  str += "PC deals ";
  str += to_string(harm);
  str += " damage to O (";
  str += to_string(getHp());
  str += " HP). ";
  if (hp <= 0) {
    v.modGold(gold);
    cellPtr->clearChar();
    str += "O is killed. PC gets ";
    str += to_string(gold);
    str += " gold. ";
  }
  return str;
}

string Orc::defend(Troll &t) {
  int harm = ceil((100.00/(100.00 + def)) * t.getAtk());
  modHp(-harm);
  string str = "";
  str += "PC deals ";
  str += to_string(harm);
  str += " damage to O (";
  str += to_string(getHp());
  str += " HP). ";
  if (hp <= 0) {
    t.modGold(gold);
    cellPtr->clearChar();
    str += "O is killed. PC gets ";
    str += to_string(gold);
    str += " gold. ";
  }
  return str;
}

string Orc::defend(Goblin &g) {
  int harm = ceil((100.00/(100.00 + def)) * g.getAtk());
  modHp(-harm);
  string str = "";
  str += "PC deals ";
  str += to_string(harm);
  str += " damage to O (";
  str += to_string(getHp());
  str += " HP). ";
  if (hp <= 0) {
    g.modGold(gold+5);
    cellPtr->clearChar();
    str += "O is killed. PC gets ";
    str += to_string(gold+5);
    str += " gold. ";
  }
  return str;
}
