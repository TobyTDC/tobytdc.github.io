#ifndef CELL_H
#define CELL_H
#include <vector>
#include <iostream>
#include <string>
#include "character.h"
#include "pc.h"
#include "item.h"

enum class CellType {Floor, VWall, HWall, Passage, Door, WhiteSpace, Stair};

class Cell {
    std::vector<Cell*> observers;
	CellType type;
	int x;
	int y;
    bool walkable;
	char content;
	Item *itemPtr;
	Character *charPtr;
	bool attacked;
public:
	Cell(CellType t, int x, int y);
	bool isWalkable() const;
	bool isOccupiable() const;
	bool isEmpty() const;
	bool isStair() const;
	int getX() const;
	int getY() const;
	void set(Item *i);
	void set(Character *c);
	void setStair();	
	void unsetStair();
	void clearChar();
	void clearItem();
	char getContent() const;
	void attach(Cell *o);
	void notifyObservers(std::string &s, PC *pc);
	bool isAttacked() const;
	void setAttacked();
 	std::string notify(PC *pc);
	std::vector<Cell*> &getObservers();
	~Cell();

	Character *returnCharPtr();
	Item *returnItemPtr();
	Cell *getNeighbour(int x, int y);
};

std::ostream &operator<<(std::ostream &out, const Cell &c);

#endif
