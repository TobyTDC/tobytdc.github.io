#include <iostream>
#include <string>
#include <stdlib.h>
#include <time.h>
#include "dwarf.h"
#include "shade.h"
#include "drow.h"
#include "vampire.h"
#include "troll.h"
#include "goblin.h"
#include <cmath>


using namespace std;




Dwarf::Dwarf(int x, int y, Cell *cellPtr) {
  	race = "Dwarf";
  	hp = 100;
  	atk = 20;
  	def = 30;

    this->x = x;
    this->y = y;
    this->cellPtr = cellPtr;
    int r = rand() % 2;
    if (r) {
      gold = 2;
    } else {
      gold = 1;
    }
    maxHp = 100;
    goodBoy = true;
    token = 'W';
}

Dwarf::~Dwarf(){}

string Dwarf::attack(Character &c) {
  if (c.getHp() <= 0) return "";
  if (hp <= 0) return "";
  return c.defend(*this);
}

string Dwarf::defend(Shade &s) {
  int harm = ceil((100.00/(100.00 + def)) * s.getAtk());
  modHp(-harm);
  string str = "";
  str += "PC deals ";
  str += to_string(harm);
  str += " damage to W (";
  str += to_string(getHp());
  str += " HP). ";
  if (hp <= 0) {
    cellPtr->clearChar();
    s.modGold(gold);
    str += "W is killed. PC gets ";
    str += to_string(gold);
    str += " gold. ";
  }
  return str;
}

string Dwarf::defend(Drow &d) {
  int harm = ceil((100.00/(100.00 + def)) * d.getAtk());
  modHp(-harm);
  string str = "";
  str += "PC deals ";
  str += to_string(harm);
  str += " damage to W (";
  str += to_string(getHp());
  str += " HP). ";
  if (hp <= 0) {
    d.modGold(gold);
    cellPtr->clearChar();
    str += "W is killed. PC gets ";
    str += to_string(gold);
    str += " gold. ";
  }
  return str;
}

string Dwarf::defend(Vampire &v) {
  int harm = ceil((100.00/(100.00 + def)) * v.getAtk());
  modHp(-harm);
  string str = "";
  v.modHp(-5);
  str += "PC deals ";
  str += to_string(harm);
  str += " damage to W (";
  str += to_string(getHp());
  str += " HP). ";
  if (hp <= 0) {
    v.modGold(gold);
    cellPtr->clearChar();
    str += "W is killed. PC gets ";
    str += to_string(gold);
    str += " gold. ";
  }
  return str;
}

string Dwarf::defend(Troll &t) {
  int harm = ceil((100.00/(100.00 + def)) * t.getAtk());
  modHp(-harm);
  string str = "";
  str += "PC deals ";
  str += to_string(harm);
  str += " damage to W (";
  str += to_string(getHp());
  str += " HP). ";
  if (hp <= 0) {
    t.modGold(gold);
    cellPtr->clearChar();
    str += "W is killed. PC gets ";
    str += to_string(gold);
    str += " gold. ";
  }
  return str;
}

string Dwarf::defend(Goblin &g) {
  int harm = ceil((100.00/(100.00 + def)) * g.getAtk());
  modHp(-harm);
  string str = "";
  str += "PC deals ";
  str += to_string(harm);
  str += " damage to W (";
  str += to_string(getHp());
  str += " HP). ";
  if (hp <= 0) {
    cellPtr->clearChar();
    g.modGold(5+gold);
    cellPtr->clearChar();
    str += "W is killed. PC gets ";
    str += to_string(gold+5);
    str += " gold. ";
  }
  return str;
}
