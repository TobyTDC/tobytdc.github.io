# ifndef GOBLIN_H
# define GOBLIN_H

#include <string>
#include "pc.h"
#include "human.h"
#include "dwarf.h"
#include "elf.h"
#include "orc.h"
#include "halfling.h"
#include "merchant.h"
#include "dragon.h"

class Goblin : public PC {
public:
  Goblin(int x, int y, Cell *cellPtr);
  ~Goblin();
  using Character::attack;
  std::string attack(Character &c) override;
  std::string defend(Elf &e) override;
  std::string defend(Halfling &ha) override;
  std::string defend(Dwarf &d) override;
  std::string defend(Human &h) override;
  std::string defend(Orc &o) override;
  std::string defend(Dragon &dr) override;
  std::string defend(Merchant &m) override;
};
  
# endif
