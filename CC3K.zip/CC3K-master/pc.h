# ifndef PC_H
# define PC_H

#include <string>
#include <map>
#include "character.h"

class Cell;

class PC : public Character {
protected:
  int adjAtk;
  int adjDef;
  std::map<std::string, bool> usedPotion;

public:
  void modAdjAtk(int adj);
  void modAdjDef(int adj);
  int getAtk() const override;
  int getDef() const override;
  int getAdjAtk() const;
  int getAdjDef() const;
  void setUsedPotion(std::string potion);
  bool isPotionUsed(std::string potion);
  std::string drinkDir(int d);
};
  
# endif