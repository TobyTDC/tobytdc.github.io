# ifndef DRAGON_H
# define DRAGON_H

#include "enemy.h"
#include <string>
#include "gold.h"

class Dragon : public Enemy {
  Gold *goldPtr;
public:
  Dragon(int x, int y, Cell *cellPtr);
  ~Dragon();
  // std::string attack(Character &c) override;
  std::string move(int d) override; // always guards its hoard
  std::string attack(Character &c) override;
  std::string defend(Shade &s) override;
  std::string defend(Drow &d) override;
  std::string defend(Vampire &v) override;
  std::string defend(Troll &t) override;
  std::string defend(Goblin &g) override;
  Gold *getGoldPtr();
  void setGoldPtr(Gold *gold);
};
  
# endif