# ifndef DWARF_H
# define DWARF_H

#include <string>
#include "enemy.h"

class Dwarf : public Enemy {
public:
  Dwarf(int x, int y, Cell *cellPtr);
  ~Dwarf();
  std::string attack(Character &c) override;
  std::string defend(Shade &s) override;
  std::string defend(Drow &d) override;
  std::string defend(Vampire &v) override;
  std::string defend(Troll &t) override;
  std::string defend(Goblin &g) override;
};
  
# endif
