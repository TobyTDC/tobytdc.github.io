# CC3K
## Spring 2017 CS246 Final Project, July 2017

Finish design & UML by July 16th    
Finish all class definitions by July 20th    
deviation: finished on July 22nd    
Test/debug the program & make adjustment until July 25th

Program designing: All    
Program implementing: All

Game & Cell & Main: Lu Wang    
Character & PC & Enemy: Yingzao Li    
Item & Gold & Potion: Dongchen Tang

Plan of Attack - first version: Lu Wang    
Plan of Attack - final version: Lu Wang    
UML - first version: Yingzao Li    
UML - final version: Dongchen Tang
