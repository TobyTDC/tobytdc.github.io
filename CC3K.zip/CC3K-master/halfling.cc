#include <iostream>
#include <string>
#include <stdlib.h>
#include "halfling.h"
#include "shade.h"
#include "drow.h"
#include "vampire.h"
#include "troll.h"
#include "goblin.h"
#include "cell.h"
#include <cmath>
using namespace std;

Halfling::Halfling(int x, int y, Cell *cellPtr) {
  	race = "Halfling";
  	hp = 100;
  	atk = 15;
  	def = 20;
    this->x = x;
    this->y = y;
    this->cellPtr = cellPtr;

    int r = rand() % 2;
    if (r) {
      gold = 2;
    } else {
      gold = 1;
    }

    maxHp = 100;
    goodBoy = true;
    token = 'L';
}

Halfling::~Halfling() {}

string Halfling::attack(Character &c) {
  if (c.getHp() <= 0) return "";
  if (hp <= 0) return "";
  return c.defend(*this);
}

string Halfling::defend(Shade &s) {
  int r = rand() % 2; // 0 or 1
  if (r) {
    int harm = ceil((100.00/(100.00 + def)) * s.getAtk());
    modHp(-harm);
    string str = "";
    str += "PC deals ";
    str += to_string(harm);
    str += " damage to L (";
    str += to_string(getHp());
    str += " HP). ";
    if (hp <= 0) {
      s.modGold(gold);
      cellPtr->clearChar();
      str += "L is killed. PC gets ";
      str += to_string(gold);
      str += " gold. ";
    }
    return str;
  } else {
    return "Aww PC missed :( ";
  }
}

string Halfling::defend(Drow &d) {
  int r = rand() % 2; // 0 or 1
  if (r) {
    int harm = ceil((100.00/(100.00 + def)) * d.getAtk());
    modHp(-harm);
    string str = "";
    str += "PC deals ";
    str += to_string(harm);
    str += " damage to L (";
    str += to_string(getHp());
    str += " HP). ";
    if (hp <= 0) {
      d.modGold(gold);
      cellPtr->clearChar();
      str += "L is killed. PC gets ";
      str += to_string(gold);
      str += " gold. ";
    }
    return str;
  } else {
    return "Aww PC missed :( ";
  }
}

string Halfling::defend(Vampire &v) {
  int r = rand() % 2; // 0 or 1
  if (r) {
    int harm = ceil((100.00/(100.00 + def)) * v.getAtk());
    modHp(-harm);
    string str = "";
    v.modHp(5);
    str += "PC deals ";
    str += to_string(harm);
    str += " damage to L (";
    str += to_string(getHp());
    str += " HP). ";
    if (hp <= 0) {
      v.modGold(gold);
      cellPtr->clearChar();
      str += "L is killed. PC gets ";
      str += to_string(gold);
      str += " gold. ";
    }
    return str;
  } else {
    return "Aww PC missed :( ";
  }
}

string Halfling::defend(Troll &t) {
  int r = rand() % 2; // 0 or 1
  if (r) {
    int harm = ceil((100.00/(100.00 + def)) * t.getAtk());
    modHp(-harm);
    string str = "";
    str += "PC deals ";
    str += to_string(harm);
    str += " damage to L (";
    str += to_string(getHp());
    str += " HP). ";
    if (hp <= 0) {
      t.modGold(gold);
      cellPtr->clearChar();
      str += "L is killed. PC gets ";
      str += to_string(gold);
      str += " gold. ";
    }
    return str;
  } else {
    return "Aww PC missed :( ";
  }
}

string Halfling::defend(Goblin &g) {
  int r = rand() % 2; // 0 or 1
  if (r) {
    int harm = ceil((100.00/(100.00 + def)) * g.getAtk());
    modHp(-harm);
    string str = "";
    str += "PC deals ";
    str += to_string(harm);
    str += " damage to L (";
    str += to_string(getHp());
    str += " HP). ";
    if (hp <= 0) {
      g.modGold(gold+5);
      cellPtr->clearChar();
      str += "L is killed. PC gets ";
      str += to_string(gold+5);
      str += " gold. ";
    }
    return str;
  } else {
    return "Aww PC missed :( ";
  }
}
