#ifndef STRATEGY_H
#define STRATEGY_H
#include <iostream>
#include "pc.h"

class Strategy{
public:
	virtual void use(PC &pc) = 0;
	virtual ~Strategy();
	//virtual Strategy();
};

#endif

