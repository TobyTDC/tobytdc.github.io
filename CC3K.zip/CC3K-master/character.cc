#include <cmath>
#include <string>
#include "cell.h"
#include "character.h"
#include <iostream>
#include "shade.h"
#include "drow.h"
#include "vampire.h"
#include "troll.h"
#include "goblin.h"
#include "human.h"
#include "dwarf.h"
#include "elf.h"
#include "orc.h"
#include "merchant.h"
#include "dragon.h"
#include "halfling.h"


using namespace std;

void Character::setBoy(int i) {}
int Character::getHp() const { return hp < 0 ? 0 : hp; }
int Character::getGold() const { return gold; }
char Character::getToken() const { return token; }
string Character::getRace() const { return race; }
Cell *Character::getCellPtr() const { return cellPtr; }
int Character::getMaxHp() const { return maxHp; }
void Character::modHp(int h) {
  if (hp + h >= maxHp) {
    hp = maxHp;
  }else {
    hp += h;
  }
}
void Character::modGold(int g) {
  gold += g;
}

Character::~Character(){}

int Character::getX() const { return x; }
int Character::getY() const { return y; }
void Character::setX(int nx) { x = nx; }
void Character::setY(int ny) { y = ny;}
bool Character::isHostile() { return false; }
string Character::defend(Shade &s){ return ""; }
string Character::defend(Drow &d){ return ""; }
string Character::defend(Vampire &v){ return ""; }
string Character::defend(Troll &t){ return ""; }
string Character::defend(Goblin &g){ return ""; }
string Character::defend(Elf &e){ return ""; }
string Character::defend(Halfling &ha){ return ""; }
string Character::defend(Dwarf &w){ return ""; }
string Character::defend(Human &h){ return ""; }
string Character::defend(Orc &o){ return ""; }
string Character::defend(Dragon &d){ return ""; }
string Character::defend(Merchant &m){ return ""; }

string Character::attackDir(int d) {

  if (d == 1) {
    Cell *charCell = cellPtr->getNeighbour(x - 1, y); // get the north Cell ptr or nullptr
    if (charCell) { // there is a cell (not nullptr)
      Character* ch = charCell->returnCharPtr(); // return the pointer of the char on that cell
      if (ch) { // there is a Character on that cell (not nullptr)
        return attack(*ch);
      } else { // 
        throw "North: no target. ";
      }
    }else{
      throw "North: no target. ";
    }

  } else if (d == 2) {
    Cell *charCell = cellPtr->getNeighbour(x - 1, y + 1); // get the no-ea Cell ptr or nullptr
    if (charCell) { // there is a cell (not nullptr)
      Character* ch = charCell->returnCharPtr(); // return the pointer of the char on that cell
      if (ch) { // there is a Character on that cell (not nullptr)
        return attack(*ch);
      } else { // 
        throw "North-east: no target. ";
      }
    }else{
      throw "North-east: no target. ";
    }
  } else if (d == 3) {
    Cell *charCell = cellPtr->getNeighbour(x, y + 1); // get the east Cell ptr or nullptr
    if (charCell) { // there is a cell (not nullptr)
      Character* ch = charCell->returnCharPtr(); // return the pointer of the char on that cell
      if (ch) { // there is a Character on that cell (not nullptr)
        return attack(*ch);
      } else { // 
        throw "East: no target. ";
      }
    }else{
      throw "East: no target. ";
    }
  } else if (d == 4) {
    Cell *charCell = cellPtr->getNeighbour(x + 1, y + 1); // get the so-ea Cell ptr or nullptr
    if (charCell) { // there is a cell (not nullptr)
      Character* ch = charCell->returnCharPtr(); // return the pointer of the char on that cell
      if (ch) { // there is a Character on that cell (not nullptr)
        return attack(*ch);
      } else { // 
        throw "South-east: no target. ";
      }
    }else{
      throw "South-east: no target. ";
    }
  } else if (d == 5) {
    Cell *charCell = cellPtr->getNeighbour(x + 1, y); // get the south Cell ptr or nullptr
    if (charCell) { // there is a cell (not nullptr)
      Character* ch = charCell->returnCharPtr(); // return the pointer of the char on that cell
      if (ch) { // there is a Character on that cell (not nullptr)
        return attack(*ch);
      } else { // 
        throw "South: no target. ";
      }
    }else{
      throw "South: no target. ";
    }
  } else if (d == 6) {
    Cell *charCell = cellPtr->getNeighbour(x + 1, y - 1); // get the so-we Cell ptr or nullptr
    if (charCell) { // there is a cell (not nullptr)
      Character* ch = charCell->returnCharPtr(); // return the pointer of the char on that cell
      if (ch) { // there is a Character on that cell (not nullptr)
        return attack(*ch);
      } else { // 
        throw "South-west: no target. ";
      }
    }else{
      throw "South-west: no target. ";
    }
  } else if (d == 7) {
    Cell *charCell = cellPtr->getNeighbour(x, y - 1); // get the west Cell ptr or nullptr
    if (charCell) { // there is a cell (not nullptr)
      Character* ch = charCell->returnCharPtr(); // return the pointer of the char on that cell
      if (ch) { // there is a Character on that cell (not nullptr)
        return attack(*ch);
      } else { // 
        throw "West: no target. ";
      }
    }else{
      throw "West: no target. ";
    }
  } else { // d == 8
    Cell *charCell = cellPtr->getNeighbour(x - 1, y - 1); // get the no-we Cell ptr or nullptr
    if (charCell) { // there is a cell (not nullptr)
      Character* ch = charCell->returnCharPtr(); // return the pointer of the char on that cell
      if (ch) { // there is a Character on that cell (not nullptr)
        return attack(*ch);
      } else { // 
        throw "North-west: no target. ";
      }
    }else{
      throw "North-west: no target. ";
    }
  }
  return "";
}


string Character::move(int d) {
  if (d == 1) { // ↑
    if (token != '@' && !(cellPtr->getNeighbour(x - 1, y)->isOccupiable())) {
      throw "North: invalid move.";
    } else if (cellPtr->getNeighbour(x - 1, y)->isWalkable()) { // the cell on the north is walkable
      x = x - 1; // ↑
      cellPtr->clearChar(); // delete this cell's ptr
      cellPtr = cellPtr->getNeighbour(x, y); // change cell ref to the new one
      cellPtr->set(this); // set the new cell's ptr
      if (token == '@') { // is PC
        return "PC moves North. ";
      }
      return "";
    } else { // invalid move
      throw "North: invalid move. ";
    }
  } else if (d == 2) { // ↗
    if (token != '@' && !(cellPtr->getNeighbour(x - 1, y + 1)->isOccupiable())) {
      throw "North-East: invalid move. ";
    } else if (cellPtr->getNeighbour(x - 1, y + 1)->isWalkable()) { // the cell on the no-ea is walkable
      x = x - 1;
      y = y + 1; // ↗
      cellPtr->clearChar(); // delete this cell's ptr
      cellPtr = cellPtr->getNeighbour(x, y); // change cell ref to the new one
      cellPtr->set(this); // set the new cell's ptr
      if (token == '@') { // is PC
        return "PC moves North-East. ";
      }
      return "";
    } else { // invalid move
      throw "North-East: invalid move. ";
    }
  } else if (d == 3) { // →
    if (token != '@' && !(cellPtr->getNeighbour(x, y + 1)->isOccupiable())) {
      throw "East: invalid move. ";
    } else if (cellPtr->getNeighbour(x, y + 1)->isWalkable()) { // the cell on the east is walkable
      y = y + 1; // →
      cellPtr->clearChar(); // delete this cell's ptr
      cellPtr = cellPtr->getNeighbour(x, y); // change cell ref to the new one
      cellPtr->set(this); // set the new cell's ptr
      if (token == '@') { // is PC
        return "PC moves East. ";
      }
      return "";
    } else { // invalid move
      throw "East: invalid move. ";
    }
  } else if (d == 4) { // ↘
    if (token != '@' && !(cellPtr->getNeighbour(x + 1, y + 1)->isOccupiable())) {
      throw "South-East: invalid move. ";
    } else if (cellPtr->getNeighbour(x + 1, y + 1)->isWalkable()) { // the cell on the so-ea is walkable
      x = x + 1;
      y = y + 1; // ↘
      cellPtr->clearChar(); // delete this cell's ptr
      cellPtr = cellPtr->getNeighbour(x, y); // change cell ref to the new one
      cellPtr->set(this); // set the new cell's ptr
      if (token == '@') { // is PC
        return "PC moves South-East. ";
      }
      return "";
    } else { // invalid move
      throw "South-East: invalid move. ";
    }
  } else if (d == 5) { // ↓
    if (token != '@' && !(cellPtr->getNeighbour(x + 1, y)->isOccupiable())) {
      throw "South: invalid move. ";
    } else if (cellPtr->getNeighbour(x + 1, y)->isWalkable()) { // the cell on the south is walkable
      x = x + 1; // ↓
      cellPtr->clearChar(); // delete this cell's ptr
      cellPtr = cellPtr->getNeighbour(x, y); // change cell ref to the new one
      cellPtr->set(this); // set the new cell's ptr
      if (token == '@') { // is PC
        return "PC moves South. ";
      }
      return "";
    } else { // invalid move
      throw "South: invalid move. ";
    }
  } else if (d == 6) { // ↙
    if (token != '@' && !(cellPtr->getNeighbour(x + 1, y - 1)->isOccupiable())) {
      throw "South-West: invalid move. ";
    } else if (cellPtr->getNeighbour(x + 1, y - 1)->isWalkable()) { // the cell on the so-we is walkable
      x = x + 1;
      y = y - 1; // ↙
      cellPtr->clearChar(); // delete this cell's ptr
      cellPtr = cellPtr->getNeighbour(x, y); // change cell ref to the new one
      cellPtr->set(this); // set the new cell's ptr
      if (token == '@') { // is PC
        return "PC moves South-West. ";
      }
      return "";
    } else { // invalid move
      throw "South-West: invalid move. ";
    }
  } else if (d == 7) { // ←
    //cout << "moving west" << endl;
    if (token != '@' && !(cellPtr->getNeighbour(x, y - 1)->isOccupiable())) {
      throw "West: invalid move. ";
    } else if (cellPtr->getNeighbour(x, y - 1)->isWalkable()) { // the cell on the west is walkable
      //cout << "walkable " << endl;
      y = y - 1; // ←
      cellPtr->clearChar(); // delete this cell's ptr
      //cout << "char cleared" << endl;
     // cout << "old ptr is " << cellPtr << endl;
      cellPtr = cellPtr->getNeighbour(x, y); // change cell ref to the new one
      //cout << "new ptr is " << cellPtr << endl;
      cellPtr->set(this); // set the new cell's ptr
     // cout << "reset" << endl;
      if (token == '@') { // is PC
        //cout << "is PC" << endl;
        return "PC moves West. ";
      }
      //cout << "is enemy" << endl;
      return "";
    } else { // invalid move
      throw "West: invalid move. ";
    }
  } else { // d == 8  ↖
    if (token != '@' && !(cellPtr->getNeighbour(x - 1, y - 1)->isOccupiable())) {
      throw "North-West: invalid move. ";
    } else if (cellPtr->getNeighbour(x - 1, y - 1)->isWalkable()) { // the cell on the no-we is walkable
      x = x - 1;
      y = y - 1; // ↖
      cellPtr->clearChar(); // delete this cell's ptr
      cellPtr = cellPtr->getNeighbour(x, y); // change cell ref to the new one
      cellPtr->set(this); // set the new cell's ptr
      if (token == '@') { // is PC
        return "PC moves North-West. ";
      }
      return "";
    } else { // invalid move
      throw "North-West: invalid move. ";
    }
  }
}
