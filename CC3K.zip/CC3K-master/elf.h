# ifndef ELF_H
# define ELF_H

#include <string>
#include "enemy.h"
#include "shade.h"
#include "vampire.h"
#include "troll.h"

#include "cell.h"

class Goblin;
class Elf : public Enemy {
public:
  Elf(int x, int y, Cell *cellPtr);
  ~Elf();
  std::string attack(Character &c) override;
  std::string defend(Shade &s) override;
  std::string defend(Drow &d) override;
  std::string defend(Vampire &v) override;
  std::string defend(Troll &t) override;
  std::string defend(Goblin &g) override;
};
  
# endif
