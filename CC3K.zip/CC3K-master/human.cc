#include <iostream>
#include <string>
#include "human.h"
#include "shade.h"
#include "drow.h"
#include "vampire.h"
#include "troll.h"
#include "goblin.h"
#include "cell.h"
#include <cmath>
using namespace std;

Human::Human(int x, int y, Cell *cellPtr) {
    race = "Human";
    hp = 140;
    atk = 20;
    def = 20;
    gold = 4;
    goodBoy = true;
    maxHp = 140;
    this->x = x;
    this->y = y;
    this->cellPtr = cellPtr;

    token = 'H';
}

string Human::attack(Character &c){
    if (c.getHp() <= 0) return "";
    if (hp <= 0) return "";
    return c.defend(*this);
}

string Human::defend(Shade &s){
    int harm = ceil((100.00/(100.00 + def)) * s.getAtk());
    modHp(-harm);
    string str = "";
    str += "PC deals " ;
    str += to_string(harm);
    str += " damage to H (";
    str += to_string(getHp());
    str += " HP). ";
    if(hp <= 0){
        cellPtr->clearChar();
        str += "H is killed. ";
        throw str;
    }
    return str;
}

string Human::defend(Drow &d){
    int harm = ceil((100.00/(100.00 + def)) * d.getAtk());
    modHp(-harm);
    string str = "";
    str += "PC deals " ;
    str += to_string(harm);
    str += " damage to H (";
    str += to_string(getHp());
    str += " HP). ";
    if(hp <= 0){
        cellPtr->clearChar();
        str += "H is killed. ";
        throw str;
    }
    return str;
}

string Human::defend(Vampire &v){
    int harm = ceil((100.00/(100.00 + def)) * v.getAtk());
    modHp(-harm);
    v.modHp(5);
    string str = "";
    str += "PC deals " ;
    str += to_string(harm);
    str += " damage to H (";
    str += to_string(getHp());
    str += " HP). ";
    if(hp <= 0){
        cellPtr->clearChar();
        str += "H is killed. ";
        throw str;
    }
    return str;
}
string Human::defend(Troll &t){
    int harm = ceil((100.00/(100.00 + def)) * t.getAtk());
    modHp(-harm);
    string str = "";
    str += "PC deals " ;
    str += to_string(harm);
    str += " damage to H (";
    str += to_string(getHp());
    str += " HP). ";
    if(hp <= 0){
        cellPtr->clearChar();
        cout << "human cleared " << endl;
        str += "H is killed. ";
        throw str;
    }
    return str;
}
string Human::defend(Goblin &g){
    int harm = ceil((100.00/(100.00 + def)) * g.getAtk());
    modHp(-harm);
    string str = "";
    str += "PC deals " ;
    str += to_string(harm);
    str += " damage to H (";
    str += to_string(getHp());
    str += " HP). ";
    if(hp <= 0){
        g.modGold(5);
        cellPtr->clearChar();
        str += "H is killed. PC gets 5 gold. ";
        throw str;
    }
    return str;
}

Human::~Human() {}
