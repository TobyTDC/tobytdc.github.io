# ifndef MERCHANT_H
# define MERCHANT_H

#include <string>
#include "enemy.h"

class Character;
class Shade;
class Drow;
class Vampire;
class Troll;
class Goblin;


class Merchant : public Enemy {
  bool hostile;
public:
  Merchant(int x, int y, Cell *cellPtr);
  ~Merchant();
  // std::string attack(Character &c) override;
  // void move(int d) override;
  void nowHostile() override;
  bool isHostile() override;
  std::string attack(Character &c) override;
  std::string defend(Shade &s) override;
  std::string defend(Drow &d) override;
  std::string defend(Vampire &v) override;
  std::string defend(Troll &t) override;
  std::string defend(Goblin &g) override;
};
  
# endif
