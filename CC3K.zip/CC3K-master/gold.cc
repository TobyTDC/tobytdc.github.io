#include "gold.h"

Gold::Gold(int amount, Cell *cellPtr):amount{amount}, cellPtr{cellPtr}, dragonPtr{nullptr}{
	dragonDead = false;
}

string Gold::use (PC &player){
	if(amount == 6 && !dragonDead) return "";
	player.modGold(amount);
	cellPtr->clearItem();
	return "PC picks up " + to_string(amount) + " gold. ";
}

void Gold::setDragon(Character *dragon){
	dragonPtr = dragon;
}

void Gold::setDragonDead(){ dragonDead = true; }
char Gold::getToken(){
	return 'G';
}

string Gold::getName(){
	return "G";
}

string Gold::alert(PC &pc){
	if(dragonPtr == nullptr ) return "PC sees " + to_string(amount) + " gold. ";
	if(dragonPtr->getHp() <= 0) return "PC sees " + to_string(amount) + " gold. ";
	string atackMessage = dragonPtr->attack(pc);
	return atackMessage + " " + "PC sees " + to_string(amount) + " gold. ";
}

bool Gold::isHoard(){
	return amount == 6;
}

Cell *Gold::getCellPtr(){
	return cellPtr;
}


