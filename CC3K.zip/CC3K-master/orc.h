# ifndef ORC_H
# define ORC_H

#include <string>
#include "enemy.h"
#include "goblin.h"
class Orc : public Enemy {
public:
  Orc(int x, int y, Cell *cellPtr);
  ~Orc();
  std::string attack(Character &c) override;
  std::string defend(Shade &s) override;
  std::string defend(Drow &d) override;
  std::string defend(Vampire &v) override;
  std::string defend(Troll &t) override;
  std::string defend(Goblin &g) override;
};
  
# endif
