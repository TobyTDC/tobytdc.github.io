#ifndef GOLD_H
#define GOLD_H
#include "item.h"
#include "cell.h"

using namespace std;


class Gold : public Item{
	int amount;
	Cell *cellPtr;
	Character *dragonPtr;
	bool dragonDead;
public:
	Gold(int amount, Cell *cellPtr); //the total amount of gold
	string use(PC& player) override; //add amount of gold to the pc player
	void setDragon(Character *dragonPtr);
	char  getToken() override; //return 'G'
	string getName() override;
	bool isHoard();
	void setDragonDead();
	string alert(PC &pc) override;
	//void clearItem() override;
	Cell *getCellPtr() override;
};

#endif

