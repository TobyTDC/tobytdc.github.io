#ifndef POTION_H
#define POTION_H
#include "item.h"
#include <string>
#include <memory>
#include "strategy.h"
#include "cell.h"

using namespace std;

class Potion : public Item{
	string name;
	Strategy *straPtr; //using unique_ptr so that we do not 
	                              //need to delete the memory manually 
	Cell *cellPtr;
public:
	 string use(PC &pc) override;//use the potion on the player character
	                            // may modify the player character
	 char getToken() override; //return 'P' 
	 string alert(PC &pc) override; 
	 string getName() override; //return the name of the potion
	 Potion(string name, Strategy *straPtr, Cell *cellPtr); // the constructor 
	 ~Potion();
	 Cell *getCellPtr() override;
	 
};

#endif

