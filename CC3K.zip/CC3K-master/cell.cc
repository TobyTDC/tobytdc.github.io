#include "cell.h"



using namespace std;

Cell::Cell(CellType t, int x, int y): type{t}, x{x}, y{y} {
  if(t ==  CellType::Floor){  
    walkable = true;
    content = '.';
    }else if(t == CellType::VWall){
			walkable = false;
			content = '|';
	}else if(t == CellType::HWall){
			walkable = false;
			content = '-';
    }else if(t == CellType::Passage){
			walkable = true;
			content = '#';
    }else if(t == CellType::Door){
			walkable = true;
			content = '+';
	}else if(t == CellType::WhiteSpace){
			walkable = false;
			content = ' ';			
	}else{
			walkable = true;
			content = '\\';
	}
	charPtr = nullptr;
	itemPtr = nullptr;
	attacked = false;
}

bool Cell::isWalkable() const{ return walkable && (!charPtr) && (getContent() != 'P'); }

bool Cell::isEmpty() const{ return (!charPtr) && (!itemPtr);}


bool Cell::isStair() const {return type == CellType::Stair;}
bool Cell::isOccupiable() const{ // check whether item/character can be placed on this cell
	return (isEmpty() && isWalkable() && 
		   (type != CellType::Door) &&
		   (type != CellType::Passage) &&
	           (type != CellType::Stair));        
}

int Cell::getX() const{return x;}
int Cell::getY() const{return y;}

void Cell::set(Item *i){itemPtr = i;}
void Cell::set(Character *c){charPtr = c;}

void Cell::clearChar(){charPtr = nullptr;}
void Cell::clearItem(){itemPtr = nullptr;}

void Cell::setAttacked(){ attacked = true; } 
bool Cell::isAttacked() const { return attacked; }
//for changing a cell to stair
void Cell::setStair(){
	type = CellType::Stair;
	content = '\\';
}
//for changing a stair back to floor
void Cell::unsetStair(){
	type = CellType::Floor;
	content = '.';
}

char Cell::getContent() const{
	if(charPtr){
	  return charPtr->getToken();
	}else if(itemPtr){
          return itemPtr->getToken();
	}else{
	  return content;
	} // for output
}


void Cell::attach(Cell *o){
	observers.emplace_back(o);
}


Character *Cell::returnCharPtr(){return charPtr;}
Item *Cell::returnItemPtr(){return itemPtr;}

Cell *Cell::getNeighbour(int x, int y){
	for(auto it = observers.begin(); it != observers.end(); ++it){
		if((*it)->getX() == x && (*it)->getY() == y) {
			return *it;
		}
	}
	return nullptr;
}


void Cell::notifyObservers(string &s, PC *pc) {
  if(itemPtr) s+=(itemPtr->use(*pc));
  for(auto it = observers.begin(); it != observers.end(); ++it){
  	if((*it)->returnCharPtr()) s+= (*it)->notify(pc);
  }
  if(pc->getHp() <= 0) return;
  for(auto it = observers.begin(); it != observers.end(); ++it){
  	if((*it)->returnItemPtr()) s+= (*it)->notify(pc);
  }
}



string Cell::notify(PC *pc){
	if(charPtr){
	  if(!charPtr->isHostile()) return ""; //merchant/dragon may not attack
		charPtr->setBoy(0); //bad boy   
 		if(!attacked) { //enemy auto attack 
		  if (pc->getHp() <= 0) return ""; //pc is already dead
		    int r = rand() % 2;
		    if(r){
		        return charPtr->attack(*pc);
		    }else{
			    string str = "";
			    str += charPtr->getToken();
			    str += " missed the attack. ";
			    return str;
		    } 
		}else{
			return charPtr->attack(*pc);
		}
	}else if(itemPtr){
		return itemPtr->alert(*pc);
	}else{
		return "";
	}
	attacked = false; //reset attacked status
}


vector<Cell*> & Cell::getObservers() {
	return observers;
}


Cell::~Cell(){}

ostream &operator<<(ostream &out, const Cell &c){
	out << c.getContent();
	return out;
}
