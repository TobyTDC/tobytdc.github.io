#include <string>
#include <stdlib.h>
#include "drow.h"
#include "human.h"
#include "dwarf.h"
#include "elf.h"
#include "orc.h"
#include "halfling.h"
#include "merchant.h"
#include "dragon.h"
#include <cmath>
#include "cell.h"
using namespace std;

Drow::Drow(int x, int y, Cell *cellPtr) {
  	race = "Drow";
  	hp = 150;
  	atk = 25;
  	def = 15;
  	gold = 0;

    this->x = x;
    this->y = y;
    this->cellPtr = cellPtr;
    maxHp = 150;

    adjAtk = 0;
    adjDef = 0;
    usedPotion = {{"RH", false}, {"BA", false}, {"BD", false}, {"PH", false}, {"WA",false}, {"WD", false}};

    token = '@';
}
 
Drow::~Drow() {}




string Drow::attack(Character &c){
  c.getCellPtr()->setAttacked();
  if(hp <= 0) return "";
  return c.defend(*this);
}

string Drow::defend(Elf &e){
   int harm = ceil((100.00/(100.00 + def)) * e.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += e.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str; 
}

string Drow::defend(Halfling &h){
   int harm = ceil((100.00/(100.00 + def)) * h.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += h.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str;
}

string Drow::defend(Dwarf &d){
   int harm = ceil((100.00/(100.00 + def)) * d.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += d.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str;
}

string Drow::defend(Human &h){
   int harm = ceil((100.00/(100.00 + def)) * h.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += h.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str;
}

string Drow::defend(Orc &o){
   int harm = ceil((100.00/(100.00 + def)) * o.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += o.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str;
}

string Drow::defend(Dragon &dr){
   int harm = ceil((100.00/(100.00 + def)) * dr.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += dr.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    dr.getGoldPtr()->setDragonDead();
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str;
}

string Drow::defend(Merchant &m){
   int harm = ceil((100.00/(100.00 + def)) * m.getAtk()); // do harm to enemy: (100 / 100+def) * atk
   modHp(-harm);
   string str= "";
   str += m.getToken();
   str += " deals ";
   str += to_string(harm);
   str += " damage to PC (";
   str += to_string(getHp());
   str += " HP). ";
   if(hp <= 0){
    cellPtr->clearChar();
    str += "PC is killed. ";
    return str;
   }
   return str;
}

/*string Drow::attack(Halfling &ha) {
  // 50% miss 
  
  int num = rand() % 2; // num is 0 or 1 (50% / 50%)
  if (num) { // 50% chance to get a 1 and attack
    int harm = ceil((100/(100 + ha.getDef())) * atk); // do harm to enemy: (100 / 100+def) * atk
    ha.modHp(-harm);

    if (ha.getHp() <= 0) { // the enemy is dead
      ha.getCellPtr()->clearChar();
      string str = "L is killed. ";
      return str;
    }
    string str = ""; // new string
    str += "PC deals ";
    str += to_string(harm);
    str += " damage to L (";
    str += to_string(ha.getHp());
    str += " HP). ";
    return str;
  } else {
    return "Awwwww PC missed! :(";
  }
}*/


