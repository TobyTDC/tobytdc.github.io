# ifndef HALFLING_H
# define HALFLING_H

#include "enemy.h"
#include <string>

class Halfling : public Enemy {
public:
  Halfling(int x, int y, Cell *cellPtr);
  ~Halfling();
  std::string attack(Character &c) override;
  std::string defend(Shade &s) override;
  std::string defend(Drow &d) override;
  std::string defend(Vampire &v) override;
  std::string defend(Troll &t) override;
  std::string defend(Goblin &g) override;
};
  
# endif