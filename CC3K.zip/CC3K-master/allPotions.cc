#include "allPotions.h"

class Drow;

using namespace std;

RH::RH(){}

RH::~RH(){}

void RH::use(PC &pc){
	if(pc.getRace() == "Drow"){
		   pc.modHp(15);
	       if(pc.getHp() > pc.getMaxHp()){
		 pc.modHp(pc.getMaxHp() - pc.getHp());
	        }
		return;
	}
	pc.modHp(10);
	if(pc.getHp() > pc.getMaxHp()){
		pc.modHp(pc.getMaxHp() - pc.getHp());
	}
}

/*void RH::use(Drow &pc){
	pc.modHp(15);
	if(pc.getHp() > pc.getMaxHp()){
		pc.modHp(pc.getMaxHp() - pc.getHp());
	}
}*/

BA::BA(){}

BA::~BA(){}

void BA::use(PC &pc){
	if(pc.getRace() == "Drow"){
		pc.modAdjAtk(5 * 1.5);
		return;
	}
	pc.modAdjAtk(5);
	
}

/*void BA::use(Drow &pc){
	pc.modAdjAtk(5 * 1.5);
	
}*/

BD::BD(){}

BD::~BD(){}

void BD::use(PC &pc){
	if(pc.getRace() == "Drow"){
		pc.modAdjDef(5 * 1.5);
		return;
	}
	pc.modAdjDef(5);
	
}

/*void BD::use(Drow &pc){
	pc.modAdjDef(5 * 1.5);
	
}*/

PH::PH(){}

PH::~PH(){}

void PH::use(PC &pc){
	if(pc.getRace()=="Drow"){
		pc.modHp(-10 * 1.5);
		return;
	}
	pc.modHp(-10);
}

/*void PH::use(Drow &pc){
	pc.modHp(-10);
	
}*/


WA::WA(){}

WA::~WA(){}

void WA::use(PC &pc){
	if(pc.getRace()=="Drow"){
		pc.modAdjAtk(-5 * 1.5);
	  if(pc.getAdjAtk() + pc.getAtk() < 0){
		pc.modAdjAtk(0 - (pc.getAdjAtk() + pc.getAtk()));
	  }
		return;
	}
	pc.modAdjAtk(-5);
	if(pc.getAdjAtk() + pc.getAtk() < 0){
		pc.modAdjAtk(0 - (pc.getAdjAtk() + pc.getAtk()));
	}
}

/*void WA::use(Drow &pc){
	pc.modAdjAtk(-5 * 1.5);
	if(pc.getAdjAtk() + pc.getAtk() < 0){
		pc.modAdjAtk(0 - (pc.getAdjAtk() + pc.getAtk()));
	}
}*/

WD::WD(){}

WD::~WD(){}

void WD::use(PC &pc){
	if(pc.getRace() == "Drow"){
		pc.modAdjDef(-5 * 1.5);
	   if(pc.getAdjDef() + pc.getDef() < 0){
		pc.modAdjDef(0 - (pc.getAdjDef() + pc.getDef()));
	   }
		return;
	}
	pc.modAdjDef(-5);
	if(pc.getAdjDef() + pc.getDef() < 0){
		pc.modAdjDef(0 - (pc.getAdjDef() + pc.getDef()));
	}
}

/*void WD::use(Drow &pc){
	pc.modAdjDef(-5 * 1.5);
	if(pc.getAdjDef() + pc.getDef() < 0){
		pc.modAdjDef(0 - (pc.getAdjDef() + pc.getDef()));
	}
}*/





